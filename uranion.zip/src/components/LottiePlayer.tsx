

const LottiePlayer = () => {

     return (
          <>
               <iframe className="3xl:w-[870px] md:w-[570px] w-[500px] 3xl:h-[600px] md:h-[500px] 3xl:-mt-[146px] lg:-mt-24 h-[300px] -ml-16" src="https://lottie.host/embed/981aa540-927e-4371-a57a-605cce20b48c/iOGCNiUJxh.lottie"></iframe>
          </>
     );
};

export default LottiePlayer;
